
		<footer class="footer" id="footer">
			<div class="row">
				<div class="col-md-12">
					<?php echo '<p><a target="_blank" href="http://www.hardeepasrani.com/portfolio/latte/">Latte</a><br/>'.__('Proudly powered by','latte').' WordPress</p>'; ?>
				</div>
			</div>
		</footer>

	</div>
<?php wp_footer(); ?>
 </body>
</html>
